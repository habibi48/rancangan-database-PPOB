--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.territories DROP CONSTRAINT fk_territories_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_suppliers;
ALTER TABLE ONLY public.products DROP CONSTRAINT fk_products_categories;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_shippers;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_employees;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders_customers;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_products;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT fk_order_details_orders;
ALTER TABLE ONLY public.employees DROP CONSTRAINT fk_employees_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_territories;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT fk_employee_territories_employees;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customers;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT fk_customer_customer_demo_customer_demographics;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.us_states DROP CONSTRAINT pk_usstates;
ALTER TABLE ONLY public.territories DROP CONSTRAINT pk_territories;
ALTER TABLE ONLY public.suppliers DROP CONSTRAINT pk_suppliers;
ALTER TABLE ONLY public.shippers DROP CONSTRAINT pk_shippers;
ALTER TABLE ONLY public.region DROP CONSTRAINT pk_region;
ALTER TABLE ONLY public.products DROP CONSTRAINT pk_products;
ALTER TABLE ONLY public.orders DROP CONSTRAINT pk_orders;
ALTER TABLE ONLY public.order_details DROP CONSTRAINT pk_order_details;
ALTER TABLE ONLY public.employees DROP CONSTRAINT pk_employees;
ALTER TABLE ONLY public.employee_territories DROP CONSTRAINT pk_employee_territories;
ALTER TABLE ONLY public.customers DROP CONSTRAINT pk_customers;
ALTER TABLE ONLY public.customer_demographics DROP CONSTRAINT pk_customer_demographics;
ALTER TABLE ONLY public.customer_customer_demo DROP CONSTRAINT pk_customer_customer_demo;
ALTER TABLE ONLY public.categories DROP CONSTRAINT pk_categories;
ALTER TABLE ONLY public.penggunaan DROP CONSTRAINT penggunaan_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_username_key;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.admin DROP CONSTRAINT admin_username_key;
ALTER TABLE ONLY public.admin DROP CONSTRAINT admin_pkey;
ALTER TABLE public.tagihan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tagihan ALTER COLUMN id_penggunaan DROP DEFAULT;
ALTER TABLE public.tagihan ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.penggunaan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.penggunaan ALTER COLUMN id_penggunaan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_admin DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_pembayaran DROP DEFAULT;
ALTER TABLE public.pelanggan ALTER COLUMN id_tarif DROP DEFAULT;
ALTER TABLE public.pelanggan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.admin ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.admin ALTER COLUMN id_admin DROP DEFAULT;
DROP TABLE public.us_states;
DROP TABLE public.territories;
DROP SEQUENCE public.tagihan_id_tagihan_seq;
DROP SEQUENCE public.tagihan_id_penggunaan_seq;
DROP SEQUENCE public.tagihan_id_pelanggan_seq;
DROP TABLE public.tagihan;
DROP TABLE public.suppliers;
DROP TABLE public.shippers;
DROP TABLE public.region;
DROP TABLE public.products;
DROP SEQUENCE public.penggunaan_id_penggunaan_seq;
DROP SEQUENCE public.penggunaan_id_pelanggan_seq;
DROP TABLE public.penggunaan;
DROP SEQUENCE public.pembayaran_id_tagihan_seq;
DROP SEQUENCE public.pembayaran_id_pembayaran_seq;
DROP SEQUENCE public.pembayaran_id_pelanggan_seq;
DROP SEQUENCE public.pembayaran_id_admin_seq;
DROP TABLE public.pembayaran;
DROP SEQUENCE public.pelanggan_id_tarif_seq;
DROP SEQUENCE public.pelanggan_id_pelanggan_seq;
DROP TABLE public.pelanggan;
DROP TABLE public.orders;
DROP TABLE public.order_details;
DROP SEQUENCE public.level_id_level_seq;
DROP TABLE public.level;
DROP TABLE public.employees;
DROP TABLE public.employee_territories;
DROP TABLE public.customers;
DROP TABLE public.customer_demographics;
DROP TABLE public.customer_customer_demo;
DROP TABLE public.categories;
DROP SEQUENCE public.admin_id_level_seq;
DROP SEQUENCE public.admin_id_admin_seq;
DROP TABLE public.admin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE admin (
    id_admin integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    nama_admin character varying(100),
    id_level integer NOT NULL
);


ALTER TABLE admin OWNER TO postgres;

--
-- Name: admin_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE admin_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE admin_id_admin_seq OWNER TO postgres;

--
-- Name: admin_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE admin_id_admin_seq OWNED BY admin.id_admin;


--
-- Name: admin_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE admin_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE admin_id_level_seq OWNER TO postgres;

--
-- Name: admin_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE admin_id_level_seq OWNED BY admin.id_level;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categories (
    category_id smallint NOT NULL,
    category_name character varying(15) NOT NULL,
    description text,
    picture bytea
);


ALTER TABLE categories OWNER TO postgres;

--
-- Name: customer_customer_demo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_customer_demo (
    customer_id bpchar NOT NULL,
    customer_type_id bpchar NOT NULL
);


ALTER TABLE customer_customer_demo OWNER TO postgres;

--
-- Name: customer_demographics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer_demographics (
    customer_type_id bpchar NOT NULL,
    customer_desc text
);


ALTER TABLE customer_demographics OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customers (
    customer_id bpchar NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24)
);


ALTER TABLE customers OWNER TO postgres;

--
-- Name: employee_territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employee_territories (
    employee_id smallint NOT NULL,
    territory_id character varying(20) NOT NULL
);


ALTER TABLE employee_territories OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employees (
    employee_id smallint NOT NULL,
    last_name character varying(20) NOT NULL,
    first_name character varying(10) NOT NULL,
    title character varying(30),
    title_of_courtesy character varying(25),
    birth_date date,
    hire_date date,
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    home_phone character varying(24),
    extension character varying(4),
    photo bytea,
    notes text,
    reports_to smallint,
    photo_path character varying(255)
);


ALTER TABLE employees OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level integer NOT NULL,
    nama_level character varying(100)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE level_id_level_seq OWNER TO postgres;

--
-- Name: level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE level_id_level_seq OWNED BY level.id_level;


--
-- Name: order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE order_details (
    order_id smallint NOT NULL,
    product_id smallint NOT NULL,
    unit_price real NOT NULL,
    quantity smallint NOT NULL,
    discount real NOT NULL
);


ALTER TABLE order_details OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    order_id smallint NOT NULL,
    customer_id bpchar,
    employee_id smallint,
    order_date date,
    required_date date,
    shipped_date date,
    ship_via smallint,
    freight real,
    ship_name character varying(40),
    ship_address character varying(60),
    ship_city character varying(15),
    ship_region character varying(15),
    ship_postal_code character varying(10),
    ship_country character varying(15)
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    nomor_kwh integer,
    nama_pelanggan character varying(100),
    alamat text,
    id_tarif integer NOT NULL
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pelanggan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pelanggan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pelanggan_id_pelanggan_seq OWNED BY pelanggan.id_pelanggan;


--
-- Name: pelanggan_id_tarif_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pelanggan_id_tarif_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pelanggan_id_tarif_seq OWNER TO postgres;

--
-- Name: pelanggan_id_tarif_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pelanggan_id_tarif_seq OWNED BY pelanggan.id_tarif;


--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran integer NOT NULL,
    id_tagihan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    tanggal_pembayaran date,
    bulan_bayar date,
    biaya_admin integer,
    total_bayar integer,
    id_admin integer NOT NULL
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: pembayaran_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_admin_seq OWNER TO postgres;

--
-- Name: pembayaran_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_admin_seq OWNED BY pembayaran.id_admin;


--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_pelanggan_seq OWNER TO postgres;

--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_pelanggan_seq OWNED BY pembayaran.id_pelanggan;


--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_pembayaran_seq OWNER TO postgres;

--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_pembayaran_seq OWNED BY pembayaran.id_pembayaran;


--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_tagihan_seq OWNER TO postgres;

--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_tagihan_seq OWNED BY pembayaran.id_tagihan;


--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    bulan date,
    tahun date,
    meter_awal character varying(100),
    meter_akhir character varying(100)
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: penggunaan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE penggunaan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE penggunaan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: penggunaan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE penggunaan_id_pelanggan_seq OWNED BY penggunaan.id_pelanggan;


--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE penggunaan_id_penggunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE penggunaan_id_penggunaan_seq OWNER TO postgres;

--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE penggunaan_id_penggunaan_seq OWNED BY penggunaan.id_penggunaan;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE products (
    product_id smallint NOT NULL,
    product_name character varying(40) NOT NULL,
    supplier_id smallint,
    category_id smallint,
    quantity_per_unit character varying(20),
    unit_price real,
    units_in_stock smallint,
    units_on_order smallint,
    reorder_level smallint,
    discontinued integer NOT NULL
);


ALTER TABLE products OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE region (
    region_id smallint NOT NULL,
    region_description bpchar NOT NULL
);


ALTER TABLE region OWNER TO postgres;

--
-- Name: shippers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE shippers (
    shipper_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    phone character varying(24)
);


ALTER TABLE shippers OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE suppliers (
    supplier_id smallint NOT NULL,
    company_name character varying(40) NOT NULL,
    contact_name character varying(30),
    contact_title character varying(30),
    address character varying(60),
    city character varying(15),
    region character varying(15),
    postal_code character varying(10),
    country character varying(15),
    phone character varying(24),
    fax character varying(24),
    homepage text
);


ALTER TABLE suppliers OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan integer NOT NULL,
    id_penggunaan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    bulan date,
    tahun date,
    jumlah_meter character varying(100),
    status integer
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_pelanggan_seq OWNED BY tagihan.id_pelanggan;


--
-- Name: tagihan_id_penggunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_penggunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_penggunaan_seq OWNER TO postgres;

--
-- Name: tagihan_id_penggunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_penggunaan_seq OWNED BY tagihan.id_penggunaan;


--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_tagihan_seq OWNER TO postgres;

--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_tagihan_seq OWNED BY tagihan.id_tagihan;


--
-- Name: territories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE territories (
    territory_id character varying(20) NOT NULL,
    territory_description bpchar NOT NULL,
    region_id smallint NOT NULL
);


ALTER TABLE territories OWNER TO postgres;

--
-- Name: us_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE us_states (
    state_id smallint NOT NULL,
    state_name character varying(100),
    state_abbr character varying(2),
    state_region character varying(50)
);


ALTER TABLE us_states OWNER TO postgres;

--
-- Name: admin id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin ALTER COLUMN id_admin SET DEFAULT nextval('admin_id_admin_seq'::regclass);


--
-- Name: admin id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin ALTER COLUMN id_level SET DEFAULT nextval('admin_id_level_seq'::regclass);


--
-- Name: level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level ALTER COLUMN id_level SET DEFAULT nextval('level_id_level_seq'::regclass);


--
-- Name: pelanggan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan ALTER COLUMN id_pelanggan SET DEFAULT nextval('pelanggan_id_pelanggan_seq'::regclass);


--
-- Name: pelanggan id_tarif; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan ALTER COLUMN id_tarif SET DEFAULT nextval('pelanggan_id_tarif_seq'::regclass);


--
-- Name: pembayaran id_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_pembayaran SET DEFAULT nextval('pembayaran_id_pembayaran_seq'::regclass);


--
-- Name: pembayaran id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_tagihan SET DEFAULT nextval('pembayaran_id_tagihan_seq'::regclass);


--
-- Name: pembayaran id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_pelanggan SET DEFAULT nextval('pembayaran_id_pelanggan_seq'::regclass);


--
-- Name: pembayaran id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_admin SET DEFAULT nextval('pembayaran_id_admin_seq'::regclass);


--
-- Name: penggunaan id_penggunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan ALTER COLUMN id_penggunaan SET DEFAULT nextval('penggunaan_id_penggunaan_seq'::regclass);


--
-- Name: penggunaan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan ALTER COLUMN id_pelanggan SET DEFAULT nextval('penggunaan_id_pelanggan_seq'::regclass);


--
-- Name: tagihan id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_tagihan SET DEFAULT nextval('tagihan_id_tagihan_seq'::regclass);


--
-- Name: tagihan id_penggunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_penggunaan SET DEFAULT nextval('tagihan_id_penggunaan_seq'::regclass);


--
-- Name: tagihan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_pelanggan SET DEFAULT nextval('tagihan_id_pelanggan_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY categories (category_id, category_name, description, picture) FROM stdin;
\.
COPY categories (category_id, category_name, description, picture) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: customer_customer_demo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_customer_demo (customer_id, customer_type_id) FROM stdin;
\.
COPY customer_customer_demo (customer_id, customer_type_id) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: customer_demographics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer_demographics (customer_type_id, customer_desc) FROM stdin;
\.
COPY customer_demographics (customer_type_id, customer_desc) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM stdin;
\.
COPY customers (customer_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax) FROM '$$PATH$$/2997.dat';

--
-- Data for Name: employee_territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employee_territories (employee_id, territory_id) FROM stdin;
\.
COPY employee_territories (employee_id, territory_id) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM stdin;
\.
COPY employees (employee_id, last_name, first_name, title, title_of_courtesy, birth_date, hire_date, address, city, region, postal_code, country, home_phone, extension, photo, notes, reports_to, photo_path) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM stdin;
\.
COPY order_details (order_id, product_id, unit_price, quantity, discount) FROM '$$PATH$$/3000.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM stdin;
\.
COPY orders (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name, ship_address, ship_city, ship_region, ship_postal_code, ship_country) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2976.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM stdin;
\.
COPY products (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock, units_on_order, reorder_level, discontinued) FROM '$$PATH$$/3002.dat';

--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY region (region_id, region_description) FROM stdin;
\.
COPY region (region_id, region_description) FROM '$$PATH$$/3003.dat';

--
-- Data for Name: shippers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY shippers (shipper_id, company_name, phone) FROM stdin;
\.
COPY shippers (shipper_id, company_name, phone) FROM '$$PATH$$/3004.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM stdin;
\.
COPY suppliers (supplier_id, company_name, contact_name, contact_title, address, city, region, postal_code, country, phone, fax, homepage) FROM '$$PATH$$/3005.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: territories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY territories (territory_id, territory_description, region_id) FROM stdin;
\.
COPY territories (territory_id, territory_description, region_id) FROM '$$PATH$$/3006.dat';

--
-- Data for Name: us_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY us_states (state_id, state_name, state_abbr, state_region) FROM stdin;
\.
COPY us_states (state_id, state_name, state_abbr, state_region) FROM '$$PATH$$/3007.dat';

--
-- Name: admin_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('admin_id_admin_seq', 1, false);


--
-- Name: admin_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('admin_id_level_seq', 1, false);


--
-- Name: level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('level_id_level_seq', 1, false);


--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pelanggan_id_pelanggan_seq', 1, false);


--
-- Name: pelanggan_id_tarif_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pelanggan_id_tarif_seq', 1, false);


--
-- Name: pembayaran_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_admin_seq', 1, false);


--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_pelanggan_seq', 1, false);


--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_pembayaran_seq', 1, false);


--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_tagihan_seq', 1, false);


--
-- Name: penggunaan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('penggunaan_id_pelanggan_seq', 1, false);


--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('penggunaan_id_penggunaan_seq', 1, false);


--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_pelanggan_seq', 1, false);


--
-- Name: tagihan_id_penggunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_penggunaan_seq', 1, false);


--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_tagihan_seq', 1, false);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id_admin);


--
-- Name: admin admin_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_username_key UNIQUE (username);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: pelanggan pelanggan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_username_key UNIQUE (username);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: penggunaan penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan
    ADD CONSTRAINT penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: categories pk_categories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT pk_categories PRIMARY KEY (category_id);


--
-- Name: customer_customer_demo pk_customer_customer_demo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT pk_customer_customer_demo PRIMARY KEY (customer_id, customer_type_id);


--
-- Name: customer_demographics pk_customer_demographics; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_demographics
    ADD CONSTRAINT pk_customer_demographics PRIMARY KEY (customer_type_id);


--
-- Name: customers pk_customers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT pk_customers PRIMARY KEY (customer_id);


--
-- Name: employee_territories pk_employee_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT pk_employee_territories PRIMARY KEY (employee_id, territory_id);


--
-- Name: employees pk_employees; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT pk_employees PRIMARY KEY (employee_id);


--
-- Name: order_details pk_order_details; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT pk_order_details PRIMARY KEY (order_id, product_id);


--
-- Name: orders pk_orders; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (order_id);


--
-- Name: products pk_products; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT pk_products PRIMARY KEY (product_id);


--
-- Name: region pk_region; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT pk_region PRIMARY KEY (region_id);


--
-- Name: shippers pk_shippers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY shippers
    ADD CONSTRAINT pk_shippers PRIMARY KEY (shipper_id);


--
-- Name: suppliers pk_suppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY suppliers
    ADD CONSTRAINT pk_suppliers PRIMARY KEY (supplier_id);


--
-- Name: territories pk_territories; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT pk_territories PRIMARY KEY (territory_id);


--
-- Name: us_states pk_usstates; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY us_states
    ADD CONSTRAINT pk_usstates PRIMARY KEY (state_id);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customer_demographics; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customer_demographics FOREIGN KEY (customer_type_id) REFERENCES customer_demographics(customer_type_id);


--
-- Name: customer_customer_demo fk_customer_customer_demo_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer_customer_demo
    ADD CONSTRAINT fk_customer_customer_demo_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: employee_territories fk_employee_territories_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: employee_territories fk_employee_territories_territories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee_territories
    ADD CONSTRAINT fk_employee_territories_territories FOREIGN KEY (territory_id) REFERENCES territories(territory_id);


--
-- Name: employees fk_employees_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT fk_employees_employees FOREIGN KEY (reports_to) REFERENCES employees(employee_id);


--
-- Name: order_details fk_order_details_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_orders FOREIGN KEY (order_id) REFERENCES orders(order_id);


--
-- Name: order_details fk_order_details_products; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_order_details_products FOREIGN KEY (product_id) REFERENCES products(product_id);


--
-- Name: orders fk_orders_customers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_customers FOREIGN KEY (customer_id) REFERENCES customers(customer_id);


--
-- Name: orders fk_orders_employees; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_employees FOREIGN KEY (employee_id) REFERENCES employees(employee_id);


--
-- Name: orders fk_orders_shippers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders_shippers FOREIGN KEY (ship_via) REFERENCES shippers(shipper_id);


--
-- Name: products fk_products_categories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_categories FOREIGN KEY (category_id) REFERENCES categories(category_id);


--
-- Name: products fk_products_suppliers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT fk_products_suppliers FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id);


--
-- Name: territories fk_territories_region; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY territories
    ADD CONSTRAINT fk_territories_region FOREIGN KEY (region_id) REFERENCES region(region_id);


--
-- PostgreSQL database dump complete
--

